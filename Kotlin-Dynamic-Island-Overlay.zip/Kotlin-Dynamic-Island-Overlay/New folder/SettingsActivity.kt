package com.example.dynamicisland

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class SettingsActivity : Activity() {

    private val prefs by lazy { IslandPrefs.prefs(this) }
    private lateinit var content: LinearLayout
    private lateinit var realVizSwitch: Switch
    private val colorButtons = ArrayList<Pair<Button, Int>>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(40))
        }
        setContentView(ScrollView(this).apply { addView(content) })

        header("Features")
        toggle("Charging animation", IslandPrefs.CHARGING, true)
        toggle("Music player", IslandPrefs.MUSIC, true)
        toggle("Visualizer bars", IslandPrefs.VISUALIZER, true)
        realVizSwitch = toggle(
            "Real audio visualizer (needs microphone permission, may not work on every phone)",
            IslandPrefs.REAL_VISUALIZER, false
        ) { on ->
            if (on && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 200)
            }
        }
        toggle("Seek bar", IslandPrefs.SEEK_BAR, true)
        toggle("Show notifications and calls", IslandPrefs.NOTIFICATIONS, true)

        header("Behavior")
        toggle("Hide in fullscreen apps and videos", IslandPrefs.HIDE_FULLSCREEN, true)
        toggle("Hide in landscape", IslandPrefs.HIDE_LANDSCAPE, true)
        toggle("Start automatically after reboot", IslandPrefs.START_ON_BOOT, true)

        header("Accent color")
        colorRow()

        header("Size")
        sizeSlider()
    }

    private fun header(title: String) {
        content.addView(TextView(this).apply {
            this.text = title
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(24), 0, dp(8))
        })
    }

    private fun toggle(
        label: String,
        key: String,
        default: Boolean,
        onChange: ((Boolean) -> Unit)? = null
    ): Switch {
        val sw = Switch(this).apply {
            text = label
            textSize = 15f
            isChecked = prefs.getBoolean(key, default)
            setPadding(0, dp(8), 0, dp(8))
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(key, checked).apply()
                onChange?.invoke(checked)
            }
        }
        content.addView(sw)
        return sw
    }

    private fun colorRow() {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val current = prefs.getInt(IslandPrefs.ACCENT, IslandPrefs.DEFAULT_ACCENT)
        for (color in IslandPrefs.ACCENT_CHOICES) {
            val b = Button(this)
            colorButtons.add(b to color)
            b.setOnClickListener {
                prefs.edit().putInt(IslandPrefs.ACCENT, color).apply()
                refreshColorButtons(color)
            }
            row.addView(b, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(12) })
        }
        content.addView(row)
        refreshColorButtons(current)
    }

    private fun refreshColorButtons(selected: Int) {
        for ((button, color) in colorButtons) {
            button.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color)
                setStroke(if (color == selected) dp(4) else dp(1), if (color == selected) Color.DKGRAY else Color.LTGRAY)
            }
        }
    }

    private fun sizeSlider() {
        val label = TextView(this)
        val current = prefs.getInt(IslandPrefs.SIZE_PERCENT, 100)
        label.text = "Island size: $current%"

        val bar = SeekBar(this).apply {
            max = 50                     // 80% .. 130%
            progress = current - 80
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    label.text = "Island size: ${p + 80}%"
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {
                    prefs.edit().putInt(IslandPrefs.SIZE_PERCENT, sb.progress + 80).apply()
                }
            })
        }
        content.addView(label)
        content.addView(bar)

        content.addView(TextView(this).apply {
            text = "Changes apply to a running island straight away."
            setTextColor(Color.GRAY)
            gravity = Gravity.START
            visibility = View.VISIBLE
            setPadding(0, dp(16), 0, 0)
        })
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 200 && grantResults.firstOrNull() != PackageManager.PERMISSION_GRANTED) {
            realVizSwitch.isChecked = false // permission refused, so turn the option back off
        }
    }
}
