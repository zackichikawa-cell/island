package com.example.dynamicisland

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowInsets
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Sizes (all in px) calculated by the service from the camera cutout and the settings. */
data class IslandMetrics(
    val cutoutW: Int,
    val collapsedW: Int,
    val collapsedH: Int,
    val chargeW: Int,
    val mediaW: Int,
    val mediaH: Int,
    val notifW: Int,
    val notifH: Int
)

enum class IslandMode { COLLAPSED, CHARGE, MEDIA, NOTIF }

class IslandView(
    context: Context,
    private val m: IslandMetrics,
    private val style: IslandStyle
) : FrameLayout(context) {

    private val accent = style.accent
    private val density = resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()

    // ---- drawing ----
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK // pure black = AMOLED pixels fully off, blends with the camera hole
        this.style = Paint.Style.FILL
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = accent
        this.style = Paint.Style.STROKE
        strokeWidth = 2.5f * density
        strokeCap = Paint.Cap.ROUND
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = accent
        this.style = Paint.Style.STROKE
        strokeWidth = 7f * density
        strokeCap = Paint.Cap.ROUND
    }
    private val rect = RectF()
    private val path = Path()
    private val segment = Path()
    private val measure = PathMeasure()

    private var ringProgress = 0f
    private var glow = 0f
    private var ringAnim: ValueAnimator? = null
    private var pulseAnim: ValueAnimator? = null

    // ---- state ----
    private var playing = false
    private var mediaShown = false
    private var currentArt: Bitmap? = null
    private var dragging = false

    // ---- callbacks the service sets ----
    var onOutsideTouch: (() -> Unit)? = null
    var onSeekTo: ((Long) -> Unit)? = null
    var onStatusBarVisible: ((Boolean) -> Unit)? = null

    // ---- content ----
    val percentText: TextView
    val titleText: TextView
    val artistText: TextView
    val prevBtn: ImageButton
    val playBtn: ImageButton
    val nextBtn: ImageButton
    val notifBtn1: TextView
    val notifBtn2: TextView
    private val notifIcon: ImageView
    private val notifTitle: TextView
    private val notifText: TextView
    private val seekBar: SeekBar
    private val elapsedText: TextView
    private val durationText: TextView
    private val chargeRow: LinearLayout
    private val mediaRow: LinearLayout
    private val seekRow: LinearLayout
    private val notifRow: LinearLayout
    private val albumArt: ImageView
    private val visualizer: VisualizerView

    init {
        setWillNotDraw(false)
        val top = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        val wrap = LinearLayout.LayoutParams.WRAP_CONTENT
        val match = LinearLayout.LayoutParams.MATCH_PARENT

        // ---------- Charging row: bolt | (camera hole) | percent ----------
        val boltWrap = FrameLayout(context).apply {
            addView(BoltView(context, accent), FrameLayout.LayoutParams(dp(12), dp(17), Gravity.CENTER))
        }
        percentText = TextView(context).apply {
            setTextColor(accent)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            text = "0%"
        }
        chargeRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(boltWrap, LinearLayout.LayoutParams(0, match, 1f))
            addView(View(context), LinearLayout.LayoutParams(m.cutoutW + dp(8), 1))
            addView(percentText, LinearLayout.LayoutParams(0, match, 1f))
            alpha = 0f
            visibility = View.INVISIBLE
        }
        addView(chargeRow, FrameLayout.LayoutParams(m.chargeW, m.collapsedH, top))

        // ---------- Media row: cover + visualizer | title/artist | prev play next ----------
        titleText = TextView(context).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            text = "Nothing playing"
        }
        artistText = TextView(context).apply {
            setTextColor(0xFF9A9A9A.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val textCol = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            addView(titleText)
            addView(artistText)
        }
        albumArt = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                setColor(0xFF1E1E1E.toInt()) // placeholder while there is no art
                cornerRadius = dp(10).toFloat()
            }
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(10).toFloat())
                }
            }
        }
        visualizer = VisualizerView(context, accent).apply {
            visibility = if (style.showVisualizer) View.VISIBLE else View.GONE
        }
        val artColumn = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            addView(albumArt, LinearLayout.LayoutParams(dp(52), dp(52)))
            addView(visualizer, LinearLayout.LayoutParams(dp(52), dp(14)).apply { topMargin = dp(5) })
        }
        prevBtn = mediaButton(android.R.drawable.ic_media_previous)
        playBtn = mediaButton(android.R.drawable.ic_media_play)
        nextBtn = mediaButton(android.R.drawable.ic_media_next)
        mediaRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(artColumn, LinearLayout.LayoutParams(dp(52), wrap))
            addView(textCol, LinearLayout.LayoutParams(0, wrap, 1f).apply { marginStart = dp(12) })
            addView(prevBtn, LinearLayout.LayoutParams(dp(42), dp(42)))
            addView(playBtn, LinearLayout.LayoutParams(dp(46), dp(46)))
            addView(nextBtn, LinearLayout.LayoutParams(dp(42), dp(42)))
            alpha = 0f
            visibility = View.INVISIBLE
        }
        addView(
            mediaRow,
            FrameLayout.LayoutParams(m.mediaW - dp(32), dp(76), top).apply { topMargin = m.collapsedH + dp(4) }
        )

        // ---------- Seek bar row ----------
        elapsedText = smallTime()
        durationText = smallTime()
        seekBar = SeekBar(context).apply {
            progressTintList = ColorStateList.valueOf(accent)
            thumbTintList = ColorStateList.valueOf(accent)
            progressBackgroundTintList = ColorStateList.valueOf(0xFF3A3A3A.toInt())
            max = 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                    if (fromUser) elapsedText.text = fmt(progress.toLong())
                }
                override fun onStartTrackingTouch(sb: SeekBar) { dragging = true }
                override fun onStopTrackingTouch(sb: SeekBar) {
                    dragging = false
                    onSeekTo?.invoke(sb.progress.toLong())
                }
            })
        }
        seekRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(elapsedText, LinearLayout.LayoutParams(dp(34), wrap))
            addView(seekBar, LinearLayout.LayoutParams(0, match, 1f))
            addView(durationText, LinearLayout.LayoutParams(dp(34), wrap))
            alpha = 0f
            visibility = View.INVISIBLE
        }
        addView(
            seekRow,
            FrameLayout.LayoutParams(m.mediaW - dp(32), dp(26), top).apply { topMargin = m.collapsedH + dp(80) }
        )

        // ---------- Notification / call row ----------
        notifIcon = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setColorFilter(Color.WHITE)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable().apply {
                setColor(0xFF1E1E1E.toInt())
                cornerRadius = dp(10).toFloat()
            }
        }
        notifTitle = TextView(context).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        notifText = TextView(context).apply {
            setTextColor(0xFF9A9A9A.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val notifCol = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            addView(notifTitle)
            addView(notifText)
        }
        notifBtn1 = pillButton()
        notifBtn2 = pillButton()
        notifRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(notifIcon, LinearLayout.LayoutParams(dp(40), dp(40)))
            addView(notifCol, LinearLayout.LayoutParams(0, wrap, 1f).apply { marginStart = dp(12) })
            addView(notifBtn1, LinearLayout.LayoutParams(wrap, wrap).apply { marginStart = dp(8) })
            addView(notifBtn2, LinearLayout.LayoutParams(wrap, wrap).apply { marginStart = dp(8) })
            alpha = 0f
            visibility = View.INVISIBLE
        }
        addView(
            notifRow,
            FrameLayout.LayoutParams(m.notifW - dp(32), dp(56), top).apply { topMargin = m.collapsedH + dp(4) }
        )
    }

    private fun mediaButton(iconRes: Int) = ImageButton(context).apply {
        setImageResource(iconRes)
        setColorFilter(Color.WHITE)
        setBackgroundColor(Color.TRANSPARENT)
        scaleType = ImageView.ScaleType.CENTER_INSIDE
        setPadding(dp(8), dp(8), dp(8), dp(8))
    }

    private fun smallTime() = TextView(context).apply {
        setTextColor(0xFF9A9A9A.toInt())
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
        text = "0:00"
    }

    private fun pillButton() = TextView(context).apply {
        setTextColor(Color.BLACK)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        maxLines = 1
        setPadding(dp(12), dp(7), dp(12), dp(7))
        background = GradientDrawable().apply {
            setColor(accent)
            cornerRadius = dp(20).toFloat()
        }
        visibility = View.GONE
    }

    private fun fmt(ms: Long): String {
        val s = max(0L, ms) / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    // ------------------------------------------------------------------
    // Drawing
    // ------------------------------------------------------------------
    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = min(h / 2f, 30f * density)

        canvas.drawRoundRect(0f, 0f, w, h, r, r, bgPaint)

        if (ringProgress > 0f) {
            val inset = ringPaint.strokeWidth / 2f + 0.5f * density
            rect.set(inset, inset, w - inset, h - inset)
            val rr = max(r - inset, 0f)
            path.rewind()
            path.addRoundRect(rect, rr, rr, Path.Direction.CW)
            measure.setPath(path, false)
            segment.rewind()
            measure.getSegment(0f, measure.length * ringProgress.coerceIn(0f, 1f), segment, true)

            if (glow > 0f) {
                glowPaint.alpha = (glow * 90).toInt()
                canvas.drawPath(segment, glowPaint)
            }
            canvas.drawPath(segment, ringPaint)
        }
    }

    // ------------------------------------------------------------------
    // Charging animation
    // ------------------------------------------------------------------
    fun startCharging(level: Int, intro: Boolean) {
        percentText.text = "$level%"
        animateRing(level / 100f, if (intro) 1100L else 0L)

        pulseAnim?.cancel()
        if (intro) {
            if (Build.VERSION.SDK_INT >= 30) performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            pulseAnim = ValueAnimator.ofFloat(0.15f, 1f).apply {
                duration = 650
                repeatCount = 5
                repeatMode = ValueAnimator.REVERSE
                addUpdateListener { glow = it.animatedValue as Float; invalidate() }
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        glow = 0.35f
                        invalidate()
                    }
                })
                start()
            }
        } else {
            glow = 0.35f
            invalidate()
        }
    }

    fun updateLevel(level: Int) {
        percentText.text = "$level%"
        animateRing(level / 100f, 400L)
    }

    fun stopCharging() {
        pulseAnim?.cancel()
        glow = 0f
        ringAnim?.cancel()
        ringAnim = ValueAnimator.ofFloat(ringProgress, 0f).apply {
            duration = 450
            interpolator = AccelerateInterpolator()
            addUpdateListener { ringProgress = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun animateRing(target: Float, durationMs: Long) {
        ringAnim?.cancel()
        if (durationMs == 0L) {
            ringProgress = target
            invalidate()
            return
        }
        ringAnim = ValueAnimator.ofFloat(ringProgress, target).apply {
            duration = durationMs
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener { ringProgress = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    // ------------------------------------------------------------------
    // Content: which row is visible
    // ------------------------------------------------------------------
    fun showContent(mode: IslandMode) {
        mediaShown = mode == IslandMode.MEDIA
        syncVisualizer()
        fade(chargeRow, mode == IslandMode.CHARGE)
        fade(mediaRow, mode == IslandMode.MEDIA)
        fade(seekRow, mode == IslandMode.MEDIA && style.showSeekBar)
        fade(notifRow, mode == IslandMode.NOTIF)
    }

    private fun fade(v: View, show: Boolean) {
        v.animate().cancel()
        if (show) {
            v.visibility = View.VISIBLE
            v.animate().alpha(1f).setStartDelay(120).setDuration(180).start()
        } else {
            v.animate().alpha(0f).setStartDelay(0).setDuration(100)
                .withEndAction { v.visibility = View.INVISIBLE }.start()
        }
    }

    // ------------------------------------------------------------------
    // Notifications, album art, progress, visualizer
    // ------------------------------------------------------------------
    fun bindNotification(icon: Drawable?, title: String, text: String, action1: String?, action2: String?) {
        notifIcon.setImageDrawable(icon)
        notifTitle.text = title
        notifText.text = text
        notifText.visibility = if (text.isBlank()) View.GONE else View.VISIBLE
        notifBtn1.text = action1 ?: ""
        notifBtn1.visibility = if (action1 != null) View.VISIBLE else View.GONE
        notifBtn2.text = action2 ?: ""
        notifBtn2.visibility = if (action2 != null) View.VISIBLE else View.GONE
    }

    fun setAlbumArt(bitmap: Bitmap?) {
        if (bitmap === currentArt) return
        currentArt = bitmap
        albumArt.setImageBitmap(bitmap)
    }

    fun setPlaying(isPlaying: Boolean) {
        playing = isPlaying
        syncVisualizer()
    }

    fun setProgress(posMs: Long, durMs: Long, enabled: Boolean) {
        seekBar.isEnabled = enabled
        if (dragging) return
        seekBar.max = if (enabled) max(1, durMs.toInt()) else 1
        seekBar.progress = if (enabled) posMs.toInt() else 0
        elapsedText.text = fmt(if (enabled) posMs else 0L)
        durationText.text = fmt(if (enabled) durMs else 0L)
    }

    /** Real audio levels (7 values, 0..1). Used instead of the simulated bars while they arrive. */
    fun feedAudio(bands: FloatArray) = visualizer.feed(bands)

    /** Bars only animate while music is playing AND the player is on screen (saves battery). */
    private fun syncVisualizer() = visualizer.setActive(playing && mediaShown)

    // ------------------------------------------------------------------
    // Fullscreen detection + touches
    // ------------------------------------------------------------------
    override fun onApplyWindowInsets(insets: WindowInsets): WindowInsets {
        if (Build.VERSION.SDK_INT >= 30) {
            onStatusBarVisible?.invoke(insets.isVisible(WindowInsets.Type.statusBars()))
        }
        return super.onApplyWindowInsets(insets)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_OUTSIDE) {
            onOutsideTouch?.invoke()
            return true
        }
        return super.onTouchEvent(event)
    }

    fun release() {
        visualizer.stop()
        ringAnim?.cancel()
        pulseAnim?.cancel()
    }

    // ------------------------------------------------------------------
    // Equalizer bars: simulated by default, driven by real audio when fed
    // ------------------------------------------------------------------
    private class VisualizerView(context: Context, tint: Int) : View(context) {
        private val barCount = 7
        private val levels = FloatArray(barCount) { 0.08f }
        private val speeds = floatArrayOf(5.1f, 7.3f, 4.2f, 8.6f, 6.0f, 4.8f, 7.9f)
        private val phases = FloatArray(barCount) { it * 1.7f }
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = tint
            style = Paint.Style.FILL
        }
        private val bar = RectF()
        private var active = false
        private var anim: ValueAnimator? = null
        private val startNs = System.nanoTime()

        @Volatile private var fed = FloatArray(barCount)
        @Volatile private var lastFeedNs = 0L

        fun feed(bands: FloatArray) {
            fed = bands.copyOf(barCount)
            lastFeedNs = System.nanoTime()
        }

        fun setActive(on: Boolean) {
            active = on
            if (on && anim == null) {
                anim = ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 1000
                    repeatCount = ValueAnimator.INFINITE
                    interpolator = LinearInterpolator()
                    addUpdateListener { step() }
                    start()
                }
            }
            // When turned off, the animator keeps running just long enough for bars to settle
        }

        fun stop() {
            anim?.cancel()
            anim = null
        }

        private fun step() {
            val now = System.nanoTime()
            val t = (now - startNs) / 1_000_000_000f
            val useReal = now - lastFeedNs < 250_000_000L
            val real = fed
            var settled = true
            for (i in 0 until barCount) {
                val target = when {
                    !active -> 0.08f
                    useReal -> 0.08f + 0.92f * real[i].coerceIn(0f, 1f)
                    else -> {
                        val a = 0.5f + 0.5f * sin(t * speeds[i] + phases[i])
                        val b = 0.5f + 0.5f * sin(t * speeds[i] * 0.37f + phases[i] * 2.1f)
                        0.12f + 0.88f * (a * 0.65f + b * 0.35f)
                    }
                }
                levels[i] += (target - levels[i]) * 0.3f
                if (!active && levels[i] > 0.09f) settled = false
            }
            invalidate()
            if (!active && settled) stop()
        }

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val barW = w / (barCount * 2 - 1)
            for (i in 0 until barCount) {
                val bh = max(levels[i] * h, barW)
                val left = i * barW * 2
                bar.set(left, (h - bh) / 2f, left + barW, (h + bh) / 2f)
                canvas.drawRoundRect(bar, barW / 2f, barW / 2f, paint)
            }
        }
    }

    /** Small lightning-bolt glyph drawn with a Path (crisp at any size). */
    private class BoltView(context: Context, tint: Int) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = tint
            style = Paint.Style.FILL
        }
        private val p = Path()

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            p.rewind()
            p.moveTo(0.60f * w, 0f)
            p.lineTo(0.15f * w, 0.56f * h)
            p.lineTo(0.46f * w, 0.56f * h)
            p.lineTo(0.38f * w, h)
            p.lineTo(0.85f * w, 0.40f * h)
            p.lineTo(0.54f * w, 0.40f * h)
            p.close()
            canvas.drawPath(p, paint)
        }
    }
}
