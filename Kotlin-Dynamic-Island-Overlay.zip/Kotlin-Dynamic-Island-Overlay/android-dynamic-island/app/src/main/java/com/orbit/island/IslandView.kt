package com.orbit.island

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Sizes (all in px) calculated by the service from the phone's camera cutout. */
data class IslandMetrics(
    val cutoutW: Int,
    val collapsedW: Int,
    val collapsedH: Int,
    val chargeW: Int,
    val mediaW: Int,
    val mediaH: Int
)

enum class IslandMode { COLLAPSED, CHARGE, MEDIA }

private val ISLAND_GREEN = 0xFF2BFF7E.toInt()

class IslandView(context: Context, private val m: IslandMetrics) : FrameLayout(context) {
    private val density = resources.displayMetrics.density
    private fun dp(value: Int) = (value * density).toInt()

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.FILL
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ISLAND_GREEN
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * density
        strokeCap = Paint.Cap.ROUND
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ISLAND_GREEN
        style = Paint.Style.STROKE
        strokeWidth = 7f * density
        strokeCap = Paint.Cap.ROUND
    }
    private val rect = RectF()
    private val path = Path()
    private val segment = Path()
    private val measure = PathMeasure()

    private var ringProgress = 0f
    private var glow = 0f
    private var ringAnim: ValueAnimator? = null
    private var pulseAnim: ValueAnimator? = null

    val percentText: TextView
    val titleText: TextView
    val artistText: TextView
    val prevBtn: ImageButton
    val playBtn: ImageButton
    val nextBtn: ImageButton
    private val chargeRow: LinearLayout
    private val mediaRow: LinearLayout
    private val albumArt: ImageView
    private val visualizer: VisualizerView
    private var playing = false
    private var mediaShown = false
    private var currentArt: Bitmap? = null

    var onOutsideTouch: (() -> Unit)? = null

    init {
        setWillNotDraw(false)

        val bolt = BoltView(context)
        val boltWrap = FrameLayout(context).apply {
            addView(bolt, LayoutParams(dp(12), dp(17), Gravity.CENTER))
        }
        percentText = TextView(context).apply {
            setTextColor(ISLAND_GREEN)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            text = "0%"
        }
        chargeRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(
                boltWrap,
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
            )
            addView(View(context), LinearLayout.LayoutParams(m.cutoutW + dp(8), 1))
            addView(
                percentText,
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
            )
            alpha = 0f
            visibility = INVISIBLE
        }
        addView(
            chargeRow,
            LayoutParams(m.chargeW, m.collapsedH, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        )

        titleText = TextView(context).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            text = "Nothing playing"
        }
        artistText = TextView(context).apply {
            setTextColor(0xFF9A9A9A.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val textCol = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            addView(titleText)
            addView(artistText)
        }
        prevBtn = mediaButton(android.R.drawable.ic_media_previous)
        playBtn = mediaButton(android.R.drawable.ic_media_play)
        nextBtn = mediaButton(android.R.drawable.ic_media_next)

        albumArt = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                setColor(0xFF1E1E1E.toInt())
                cornerRadius = dp(10).toFloat()
            }
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(10).toFloat())
                }
            }
        }
        visualizer = VisualizerView(context)
        val artColumn = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            addView(albumArt, LinearLayout.LayoutParams(dp(52), dp(52)))
            addView(
                visualizer,
                LinearLayout.LayoutParams(dp(52), dp(14)).apply { topMargin = dp(5) }
            )
        }
        val textLp = LinearLayout.LayoutParams(
            0,
            LinearLayout.LayoutParams.WRAP_CONTENT,
            1f
        ).apply {
            marginStart = dp(12)
        }
        mediaRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(
                artColumn,
                LinearLayout.LayoutParams(dp(52), LinearLayout.LayoutParams.WRAP_CONTENT)
            )
            addView(textCol, textLp)
            addView(prevBtn, LinearLayout.LayoutParams(dp(42), dp(42)))
            addView(playBtn, LinearLayout.LayoutParams(dp(46), dp(46)))
            addView(nextBtn, LinearLayout.LayoutParams(dp(42), dp(42)))
            alpha = 0f
            visibility = INVISIBLE
        }
        addView(
            mediaRow,
            LayoutParams(m.mediaW - dp(32), dp(76), Gravity.TOP or Gravity.CENTER_HORIZONTAL)
                .apply { topMargin = m.collapsedH + dp(4) }
        )
    }

    private fun mediaButton(iconRes: Int) = ImageButton(context).apply {
        setImageResource(iconRes)
        setColorFilter(Color.WHITE)
        setBackgroundColor(Color.TRANSPARENT)
        scaleType = ImageView.ScaleType.CENTER_INSIDE
        setPadding(dp(8), dp(8), dp(8), dp(8))
        contentDescription = when (iconRes) {
            android.R.drawable.ic_media_previous -> "Previous track"
            android.R.drawable.ic_media_next -> "Next track"
            else -> "Play or pause"
        }
    }

    override fun onDraw(canvas: Canvas) {
        val width = width.toFloat()
        val height = height.toFloat()
        val radius = min(height / 2f, 30f * density)
        canvas.drawRoundRect(0f, 0f, width, height, radius, radius, bgPaint)

        if (ringProgress > 0f) {
            val inset = ringPaint.strokeWidth / 2f + 0.5f * density
            rect.set(inset, inset, width - inset, height - inset)
            val ringRadius = max(radius - inset, 0f)
            path.rewind()
            path.addRoundRect(rect, ringRadius, ringRadius, Path.Direction.CW)
            measure.setPath(path, false)
            segment.rewind()
            measure.getSegment(
                0f,
                measure.length * ringProgress.coerceIn(0f, 1f),
                segment,
                true
            )

            if (glow > 0f) {
                glowPaint.alpha = (glow * 90).toInt()
                canvas.drawPath(segment, glowPaint)
            }
            canvas.drawPath(segment, ringPaint)
        }
    }

    fun startCharging(level: Int, intro: Boolean) {
        percentText.text = "$level%"
        animateRing(level / 100f, if (intro) 1100L else 0L)
        pulseAnim?.cancel()
        if (intro) {
            if (Build.VERSION.SDK_INT >= 30) {
                performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            }
            pulseAnim = ValueAnimator.ofFloat(0.15f, 1f).apply {
                duration = 650
                repeatCount = 5
                repeatMode = ValueAnimator.REVERSE
                addUpdateListener {
                    glow = it.animatedValue as Float
                    invalidate()
                }
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        glow = 0.35f
                        invalidate()
                    }
                })
                start()
            }
        } else {
            glow = 0.35f
            invalidate()
        }
    }

    fun updateLevel(level: Int) {
        percentText.text = "$level%"
        animateRing(level / 100f, 400L)
    }

    fun stopCharging() {
        pulseAnim?.cancel()
        glow = 0f
        ringAnim?.cancel()
        ringAnim = ValueAnimator.ofFloat(ringProgress, 0f).apply {
            duration = 450
            interpolator = AccelerateInterpolator()
            addUpdateListener {
                ringProgress = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun animateRing(target: Float, durationMs: Long) {
        ringAnim?.cancel()
        if (durationMs == 0L) {
            ringProgress = target
            invalidate()
            return
        }
        ringAnim = ValueAnimator.ofFloat(ringProgress, target).apply {
            duration = durationMs
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener {
                ringProgress = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun showContent(mode: IslandMode) {
        mediaShown = mode == IslandMode.MEDIA
        syncVisualizer()
        fade(chargeRow, mode == IslandMode.CHARGE)
        fade(mediaRow, mode == IslandMode.MEDIA)
    }

    private fun fade(view: View, show: Boolean) {
        view.animate().cancel()
        if (show) {
            view.visibility = VISIBLE
            view.animate().alpha(1f).setStartDelay(120).setDuration(180).start()
        } else {
            view.animate().alpha(0f).setStartDelay(0).setDuration(100)
                .withEndAction { view.visibility = INVISIBLE }
                .start()
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_OUTSIDE) {
            onOutsideTouch?.invoke()
            return true
        }
        return super.onTouchEvent(event)
    }

    fun setAlbumArt(bitmap: Bitmap?) {
        if (bitmap === currentArt) return
        currentArt = bitmap
        albumArt.setImageBitmap(bitmap)
    }

    fun setPlaying(isPlaying: Boolean) {
        playing = isPlaying
        syncVisualizer()
    }

    private fun syncVisualizer() {
        visualizer.setActive(playing && mediaShown)
    }

    fun release() {
        visualizer.stop()
        ringAnim?.cancel()
        pulseAnim?.cancel()
    }

    private class VisualizerView(context: Context) : View(context) {
        private val barCount = 7
        private val levels = FloatArray(barCount) { 0.08f }
        private val speeds = floatArrayOf(5.1f, 7.3f, 4.2f, 8.6f, 6.0f, 4.8f, 7.9f)
        private val phases = FloatArray(barCount) { it * 1.7f }
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = ISLAND_GREEN
            style = Paint.Style.FILL
        }
        private val bar = RectF()
        private var active = false
        private var anim: ValueAnimator? = null
        private val startNs = System.nanoTime()

        fun setActive(on: Boolean) {
            active = on
            if (on && anim == null) {
                anim = ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 1000
                    repeatCount = ValueAnimator.INFINITE
                    interpolator = LinearInterpolator()
                    addUpdateListener { step() }
                    start()
                }
            }
        }

        fun stop() {
            anim?.cancel()
            anim = null
        }

        private fun step() {
            val time = (System.nanoTime() - startNs) / 1_000_000_000f
            var settled = true
            for (index in 0 until barCount) {
                val target = if (active) {
                    val a = 0.5f + 0.5f * sin(time * speeds[index] + phases[index])
                    val b = 0.5f + 0.5f * sin(
                        time * speeds[index] * 0.37f + phases[index] * 2.1f
                    )
                    0.12f + 0.88f * (a * 0.65f + b * 0.35f)
                } else {
                    0.08f
                }
                levels[index] += (target - levels[index]) * 0.3f
                if (!active && levels[index] > 0.09f) settled = false
            }
            invalidate()
            if (!active && settled) stop()
        }

        override fun onDraw(canvas: Canvas) {
            val width = width.toFloat()
            val height = height.toFloat()
            val barWidth = width / (barCount * 2 - 1)
            for (index in 0 until barCount) {
                val barHeight = max(levels[index] * height, barWidth)
                val left = index * barWidth * 2
                bar.set(left, (height - barHeight) / 2f, left + barWidth, (height + barHeight) / 2f)
                canvas.drawRoundRect(bar, barWidth / 2f, barWidth / 2f, paint)
            }
        }
    }

    private class BoltView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = ISLAND_GREEN
            style = Paint.Style.FILL
        }
        private val bolt = Path()

        override fun onDraw(canvas: Canvas) {
            val width = width.toFloat()
            val height = height.toFloat()
            bolt.rewind()
            bolt.moveTo(0.60f * width, 0f)
            bolt.lineTo(0.15f * width, 0.56f * height)
            bolt.lineTo(0.46f * width, 0.56f * height)
            bolt.lineTo(0.38f * width, height)
            bolt.lineTo(0.85f * width, 0.40f * height)
            bolt.lineTo(0.54f * width, 0.40f * height)
            bolt.close()
            canvas.drawPath(bolt, paint)
        }
    }
}
