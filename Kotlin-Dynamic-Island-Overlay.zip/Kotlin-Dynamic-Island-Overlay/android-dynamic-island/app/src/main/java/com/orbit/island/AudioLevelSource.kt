package com.orbit.island

import android.media.audiofx.Visualizer
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Reads audio output levels for the optional visualizer. It does not record or store audio.
 * Some devices do not permit global output capture; start() then returns false.
 */
class AudioLevelSource(private val onBands: (FloatArray) -> Unit) {
    private var visualizer: Visualizer? = null
    private val edges = intArrayOf(1, 2, 4, 7, 12, 20, 34, 60)

    fun start(): Boolean {
        if (visualizer != null) return true
        return try {
            val capture = Visualizer(0)
            capture.setCaptureSize(Visualizer.getCaptureSizeRange()[0])
            capture.setDataCaptureListener(
                object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(
                        visualizer: Visualizer?,
                        waveform: ByteArray?,
                        samplingRate: Int
                    ) = Unit

                    override fun onFftDataCapture(
                        visualizer: Visualizer?,
                        fft: ByteArray?,
                        samplingRate: Int
                    ) {
                        if (fft != null) onBands(toBands(fft))
                    }
                },
                Visualizer.getMaxCaptureRate() / 2,
                false,
                true
            )
            capture.enabled = true
            visualizer = capture
            true
        } catch (_: Exception) {
            false
        }
    }

    fun stop() {
        try {
            visualizer?.enabled = false
            visualizer?.release()
        } catch (_: Exception) {
            // The platform may have already released the visualizer.
        }
        visualizer = null
    }

    private fun toBands(fft: ByteArray): FloatArray {
        val bins = fft.size / 2
        val result = FloatArray(7)
        for (band in 0 until 7) {
            val from = min(edges[band], bins - 1)
            val to = max(min(edges[band + 1], bins), from + 1)
            var sum = 0f
            var count = 0
            for (bin in from until to) {
                val real = fft[2 * bin].toFloat()
                val imaginary = fft[2 * bin + 1].toFloat()
                sum += hypot(real, imaginary)
                count++
            }
            val average = if (count > 0) sum / count else 0f
            result[band] = min(1f, sqrt(average / 90f))
        }
        return result
    }
}
