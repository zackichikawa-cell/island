package com.orbit.island

import android.content.Context
import android.content.SharedPreferences

data class IslandStyle(
    val accent: Int,
    val showCharging: Boolean,
    val showMusic: Boolean,
    val showVisualizer: Boolean,
    val realVisualizer: Boolean,
    val showSeekBar: Boolean,
    val showNotifications: Boolean,
    val sizePercent: Int
)

object IslandPrefs {
    const val FILE = "island_prefs"
    const val ENABLED = "enabled"
    const val START_ON_BOOT = "start_on_boot"
    const val CHARGING = "charging"
    const val MUSIC = "music"
    const val VISUALIZER = "visualizer"
    const val REAL_VISUALIZER = "real_visualizer"
    const val SEEK_BAR = "seek_bar"
    const val NOTIFICATIONS = "notifications"
    const val HIDE_FULLSCREEN = "hide_fullscreen"
    const val HIDE_LANDSCAPE = "hide_landscape"
    const val ACCENT = "accent"
    const val SIZE_PERCENT = "size_percent"

    const val DEFAULT_ACCENT = 0xFF2BFF7E.toInt()

    val ACCENT_CHOICES = intArrayOf(
        0xFF2BFF7E.toInt(),
        0xFF3D9BFF.toInt(),
        0xFFFF4FA3.toInt(),
        0xFFFF9F1A.toInt(),
        0xFFFFFFFF.toInt()
    )

    fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun style(context: Context): IslandStyle {
        val preferences = prefs(context)
        return IslandStyle(
            accent = preferences.getInt(ACCENT, DEFAULT_ACCENT),
            showCharging = preferences.getBoolean(CHARGING, true),
            showMusic = preferences.getBoolean(MUSIC, true),
            showVisualizer = preferences.getBoolean(VISUALIZER, true),
            realVisualizer = preferences.getBoolean(REAL_VISUALIZER, false),
            showSeekBar = preferences.getBoolean(SEEK_BAR, true),
            showNotifications = preferences.getBoolean(NOTIFICATIONS, true),
            sizePercent = preferences.getInt(SIZE_PERCENT, 100).coerceIn(80, 130)
        )
    }

    fun hideInFullscreen(context: Context) =
        prefs(context).getBoolean(HIDE_FULLSCREEN, true)

    fun hideInLandscape(context: Context) =
        prefs(context).getBoolean(HIDE_LANDSCAPE, true)
}
