package com.orbit.island

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var permissionStatus: TextView
    private lateinit var permissionButton: Button
    private lateinit var mediaAccessStatus: TextView
    private lateinit var mediaAccessButton: Button
    private lateinit var primaryButton: Button
    private lateinit var serviceStatus: TextView
    private var startAfterOverlayPermission = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(11, 13, 17)
        window.navigationBarColor = Color.rgb(11, 13, 17)
        window.decorView.systemUiVisibility = 0
        setContentView(buildScreen())
        refreshState()
    }

    override fun onResume() {
        super.onResume()
        refreshState()
    }

    @Deprecated("Uses the system overlay-permission settings result.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_OVERLAY_PERMISSION) {
            refreshState()
            if (startAfterOverlayPermission && Settings.canDrawOverlays(this)) {
                startAfterOverlayPermission = false
                requestNotificationsThenStart()
            } else {
                startAfterOverlayPermission = false
            }
        }
    }

    @Deprecated("Uses the Android runtime notification permission callback.")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_NOTIFICATIONS) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
                startOverlayService()
            } else {
                Toast.makeText(
                    this,
                    "Allow notifications to keep the overlay visible and easy to stop.",
                    Toast.LENGTH_LONG
                ).show()
            }
            refreshState()
        }
    }

    private fun buildScreen(): View {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(BACKGROUND)
            isFillViewport = true
            clipToPadding = false
            setOnApplyWindowInsetsListener { view, insets ->
                view.setPadding(
                    dp(22),
                    insets.systemWindowInsetTop + dp(22),
                    dp(22),
                    insets.systemWindowInsetBottom + dp(24)
                )
                insets
            }
        }

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(
            page,
            ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT
            )
        )
        scroll.requestApplyInsets()

        val brand = TextView(this).apply {
            text = "DYNAMIC ISLAND  /  ANDROID"
            textSize = 12f
            letterSpacing = 0.14f
            setTextColor(ACCENT)
            typeface = Typeface.DEFAULT_BOLD
        }
        page.addView(brand)
        addGap(page, 14)

        page.addView(
            text(
                value = "Dynamic Island",
                size = 34f,
                color = TEXT,
                bold = true
            )
        )
        addGap(page, 8)
        page.addView(
            text(
                value = "Charging alerts and media controls in a compact overlay.",
                size = 16f,
                color = MUTED
            )
        )
        addGap(page, 26)

        val preview = panel()
        preview.addView(
            text("LIVE PREVIEW", 11f, ACCENT, bold = true).apply {
                letterSpacing = 0.12f
            }
        )
        addGap(preview, 14)
        val island = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(15), 0, dp(15), 0)
            background = rounded(Color.rgb(4, 5, 7), 28)
        }
        val liveDot = View(this).apply {
            background = oval(ACCENT)
            contentDescription = "Live activity indicator"
        }
        island.addView(liveDot, LinearLayout.LayoutParams(dp(8), dp(8)))
        island.addView(
            text("Charging", 13f, TEXT, bold = true).apply {
                setPadding(dp(10), 0, 0, 0)
            },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        island.addView(text("84%", 13f, MUTED, bold = true))
        preview.addView(
            island,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(50)
            )
        )
        addGap(page, 16)
        page.addView(preview)
        addGap(page, 18)

        val permissionPanel = panel()
        permissionPanel.addView(
            text("Overlay access", 17f, TEXT, bold = true)
        )
        addGap(permissionPanel, 6)
        permissionStatus = text("", 14f, MUTED)
        permissionPanel.addView(permissionStatus)
        addGap(permissionPanel, 14)
        permissionButton = button(
            label = "Open overlay settings",
            fill = SURFACE_LIGHT,
            foreground = TEXT
        ).apply {
            setOnClickListener { openOverlaySettings(startAfterGrant = false) }
        }
        permissionPanel.addView(permissionButton)
        addGap(page, 16)
        page.addView(permissionPanel)
        addGap(page, 16)

        val mediaPanel = panel()
        mediaPanel.addView(text("Media access", 17f, TEXT, bold = true))
        addGap(mediaPanel, 6)
        mediaAccessStatus = text("", 14f, MUTED)
        mediaPanel.addView(mediaAccessStatus)
        addGap(mediaPanel, 14)
        mediaAccessButton = button(
            label = "Open notification access settings",
            fill = SURFACE_LIGHT,
            foreground = TEXT
        ).apply {
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }
        mediaPanel.addView(mediaAccessButton)
        addGap(page, 16)
        page.addView(mediaPanel)
        addGap(page, 16)

        serviceStatus = text("", 13f, MUTED)
        page.addView(serviceStatus)
        addGap(page, 10)
        primaryButton = button(
            label = "Start overlay",
            fill = ACCENT,
            foreground = Color.rgb(18, 23, 13)
        ).apply {
            setOnClickListener {
                if (isServiceRunning()) {
                    stopOverlayService()
                } else if (!Settings.canDrawOverlays(this@MainActivity)) {
                    openOverlaySettings(startAfterGrant = true)
                } else {
                    requestNotificationsThenStart()
                }
            }
        }
        page.addView(primaryButton)
        addGap(page, 22)

        val howItWorks = panel()
        howItWorks.addView(
            text("How it works", 17f, TEXT, bold = true)
        )
        addGap(howItWorks, 8)
        howItWorks.addView(
            text(
                "Charging status appears when your phone is plugged in. Tap the pill for media controls. Android’s optional Notification access is broad; this app uses it only for active media sessions and never reads notification text. Stop the service from its ongoing notification.",
                14f,
                MUTED
            )
        )
        page.addView(howItWorks)
        addGap(page, 22)
        page.addView(
            text(
                "Media access is optional. The overlay only handles taps inside its visible pill.",
                12f,
                MUTED
            ).apply {
                gravity = Gravity.CENTER
            }
        )

        return scroll
    }

    private fun requestNotificationsThenStart() {
        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                REQUEST_NOTIFICATIONS
            )
            return
        }
        startOverlayService()
    }

    private fun startOverlayService() {
        if (!Settings.canDrawOverlays(this)) {
            openOverlaySettings(startAfterGrant = true)
            return
        }
        val serviceIntent = Intent(this, DynamicIslandService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
        Handler(Looper.getMainLooper()).postDelayed({ refreshState() }, 400)
    }

    private fun stopOverlayService() {
        stopService(Intent(this, DynamicIslandService::class.java))
        Handler(Looper.getMainLooper()).postDelayed({ refreshState() }, 150)
    }

    private fun openOverlaySettings(startAfterGrant: Boolean) {
        startAfterOverlayPermission = startAfterGrant
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        @Suppress("DEPRECATION")
        startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION)
    }

    private fun refreshState() {
        if (!::permissionStatus.isInitialized) return

        val canOverlay = Settings.canDrawOverlays(this)
        val running = isServiceRunning()
        permissionStatus.text = if (canOverlay) {
            "Allowed. Dynamic Island can show its pill above other apps."
        } else {
            "Not allowed yet. Android will ask before the island can appear."
        }
        permissionStatus.setTextColor(if (canOverlay) ACCENT else MUTED)
        permissionButton.text = if (canOverlay) "Review overlay settings" else "Open overlay settings"
        val canAccessMedia = hasNotificationAccess()
        mediaAccessStatus.text = if (canAccessMedia) {
            "Enabled. Active song details and playback controls are available."
        } else {
            "Optional. Allow access to show current song details and playback controls."
        }
        mediaAccessStatus.setTextColor(if (canAccessMedia) ACCENT else MUTED)
        mediaAccessButton.text = if (canAccessMedia) {
            "Review notification access"
        } else {
            "Open notification access settings"
        }
        serviceStatus.text = if (running) {
            "Overlay is active. Use this button or its ongoing notification to stop it."
        } else {
            "Overlay is off."
        }
        serviceStatus.setTextColor(if (running) ACCENT else MUTED)
        primaryButton.text = when {
            running -> "Stop overlay"
            !canOverlay -> "Grant access and start"
            else -> "Start overlay"
        }
        primaryButton.background = rounded(if (running) STOP_COLOR else ACCENT, 14)
        primaryButton.setTextColor(if (running) Color.WHITE else Color.rgb(18, 23, 13))
    }

    private fun isServiceRunning(): Boolean = DynamicIslandService.isActive

    private fun hasNotificationAccess(): Boolean {
        val enabledListeners = Settings.Secure.getString(
            contentResolver,
            "enabled_notification_listeners"
        )
        return enabledListeners?.contains(packageName) == true
    }

    private fun panel(): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = rounded(SURFACE, 18, BORDER)
        }

    private fun text(
        value: String,
        size: Float,
        color: Int,
        bold: Boolean = false
    ): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        includeFontPadding = true
    }

    private fun button(label: String, fill: Int, foreground: Int): Button =
        Button(this).apply {
            text = label
            textSize = 14f
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(foreground)
            background = rounded(fill, 14)
            stateListAnimator = null
            minHeight = dp(50)
            setPadding(dp(14), 0, dp(14), 0)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(50)
            )
        }

    private fun addGap(parent: LinearLayout, heightDp: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(heightDp)))
    }

    private fun rounded(fill: Int, radiusDp: Int, stroke: Int? = null) =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(fill)
            cornerRadius = dp(radiusDp).toFloat()
            stroke?.let { setStroke(dp(1), it) }
        }

    private fun oval(fill: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(fill)
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val REQUEST_OVERLAY_PERMISSION = 401
        private const val REQUEST_NOTIFICATIONS = 402

        private val BACKGROUND = Color.rgb(11, 13, 17)
        private val SURFACE = Color.rgb(20, 24, 32)
        private val SURFACE_LIGHT = Color.rgb(37, 43, 54)
        private val BORDER = Color.rgb(39, 45, 56)
        private val TEXT = Color.rgb(244, 246, 250)
        private val MUTED = Color.rgb(155, 163, 180)
        private val ACCENT = Color.rgb(184, 243, 107)
        private val STOP_COLOR = Color.rgb(164, 59, 67)
    }
}
