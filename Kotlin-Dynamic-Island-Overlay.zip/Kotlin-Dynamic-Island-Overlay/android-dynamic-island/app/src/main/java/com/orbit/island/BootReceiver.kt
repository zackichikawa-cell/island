package com.orbit.island

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.util.Log

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (
            action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) return

        val preferences = IslandPrefs.prefs(context)
        val wasRunning = preferences.getBoolean(IslandPrefs.ENABLED, false)
        val startOnBoot = preferences.getBoolean(IslandPrefs.START_ON_BOOT, true)
        if (!wasRunning || !startOnBoot || !Settings.canDrawOverlays(context)) return

        try {
            val serviceIntent = Intent(context, DynamicIslandService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } catch (exception: Exception) {
            Log.w("BootReceiver", "Android did not allow the island service to start.", exception)
        }
    }
}
