package com.orbit.island

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.Toast
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.URL
import java.util.concurrent.Executors
import javax.net.ssl.HttpsURLConnection
import kotlin.math.max
import kotlin.math.min

class DynamicIslandService : Service() {
    private val extraWidthDp = 40
    private val extraHeightDp = 12
    private val chargeSideDp = 56
    private val mediaWidthDp = 330
    private val peekDurationMs = 2800L
    private val fallbackCutoutWDp = 12
    private val fallbackCutoutHDp = 12
    private val fallbackCutoutTopDp = 14

    private lateinit var windowManager: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var island: IslandView? = null
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var metrics: IslandMetrics
    private var animator: ValueAnimator? = null
    private var mode = IslandMode.COLLAPSED
    private var ready = false

    private var charging = false
    private var batterySeen = false

    private var controller: MediaController? = null
    private var sessionManager: MediaSessionManager? = null
    private val listenerComponent by lazy {
        ComponentName(this, MediaListenerService::class.java)
    }
    private var artKey: String? = null
    private val artExecutor = Executors.newSingleThreadExecutor()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        try {
            addIsland()
            isActive = true
            setupMedia()
            registerBattery()
            ready = true
        } catch (_: SecurityException) {
            stopSelf()
        } catch (_: WindowManager.BadTokenException) {
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!ready || !Settings.canDrawOverlays(this)) {
            stopSelf(startId)
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        ready = false
        isActive = false
        handler.removeCallbacksAndMessages(null)
        artExecutor.shutdownNow()
        animator?.cancel()
        try {
            unregisterReceiver(batteryReceiver)
        } catch (_: IllegalArgumentException) {
            // The receiver was not registered if startup ended early.
        }
        controller?.unregisterCallback(controllerCallback)
        try {
            sessionManager?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (_: SecurityException) {
            // Notification access may have been revoked before service shutdown.
        }
        island?.let { view ->
            view.release()
            if (view.isAttachedToWindow) {
                try {
                    windowManager.removeView(view)
                } catch (_: IllegalArgumentException) {
                    // The view was already removed by the system.
                }
            }
        }
        island = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    private fun buildMetrics(): Pair<IslandMetrics, Int> {
        var cutoutWidth = 0
        var cutoutHeight = 0
        var cutoutTop = 0

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val displayManager = getSystemService(DISPLAY_SERVICE) as DisplayManager
            val cutout = displayManager.getDisplay(Display.DEFAULT_DISPLAY)?.cutout?.boundingRectTop
            if (cutout != null && !cutout.isEmpty) {
                cutoutWidth = cutout.width()
                cutoutHeight = cutout.height()
                cutoutTop = cutout.top
            }
        }
        if (cutoutWidth <= 0) {
            cutoutWidth = dp(fallbackCutoutWDp)
            cutoutHeight = dp(fallbackCutoutHDp)
            cutoutTop = dp(fallbackCutoutTopDp)
        }

        val screenWidth = resources.displayMetrics.widthPixels
        val collapsedHeight = max(cutoutHeight + dp(extraHeightDp), dp(32))
        val collapsedWidth = cutoutWidth + dp(extraWidthDp)
        val chargeWidth = min(cutoutWidth + dp(chargeSideDp * 2), screenWidth - dp(24))
        val mediaWidth = min(dp(mediaWidthDp), screenWidth - dp(24))
        val mediaHeight = collapsedHeight + dp(94)
        val y = max(0, cutoutTop + cutoutHeight / 2 - collapsedHeight / 2)

        return IslandMetrics(
            cutoutWidth,
            collapsedWidth,
            collapsedHeight,
            chargeWidth,
            mediaWidth,
            mediaHeight
        ) to y
    }

    private fun addIsland() {
        val (measured, y) = buildMetrics()
        metrics = measured

        val view = IslandView(this, metrics).apply {
            setOnClickListener { onIslandTapped() }
            onOutsideTouch = {
                if (mode == IslandMode.MEDIA) animateTo(IslandMode.COLLAPSED)
            }
            prevBtn.setOnClickListener { skip(previous = true) }
            nextBtn.setOnClickListener { skip(previous = false) }
            playBtn.setOnClickListener { togglePlayPause() }
        }

        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        params = WindowManager.LayoutParams(
            metrics.collapsedW,
            metrics.collapsedH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            this.x = 0
            this.y = y
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        windowManager.addView(view, params)
        island = view
    }

    private val collapseRunnable = Runnable {
        if (mode == IslandMode.CHARGE) animateTo(IslandMode.COLLAPSED)
    }

    private fun onIslandTapped() {
        if (mode == IslandMode.MEDIA) {
            animateTo(IslandMode.COLLAPSED)
        } else {
            if (controller == null) setupMedia()
            updateMedia()
            animateTo(IslandMode.MEDIA)
        }
    }

    private fun animateTo(newMode: IslandMode) {
        val view = island ?: return
        mode = newMode
        handler.removeCallbacks(collapseRunnable)

        val endWidth = when (newMode) {
            IslandMode.COLLAPSED -> metrics.collapsedW
            IslandMode.CHARGE -> metrics.chargeW
            IslandMode.MEDIA -> metrics.mediaW
        }
        val endHeight = if (newMode == IslandMode.MEDIA) metrics.mediaH else metrics.collapsedH
        view.showContent(newMode)

        val startWidth = params.width
        val startHeight = params.height
        animator?.cancel()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 320
            interpolator = if (newMode == IslandMode.COLLAPSED) {
                DecelerateInterpolator()
            } else {
                OvershootInterpolator(0.8f)
            }
            addUpdateListener { value ->
                val fraction = value.animatedValue as Float
                params.width = max(1, (startWidth + (endWidth - startWidth) * fraction).toInt())
                params.height = max(1, (startHeight + (endHeight - startHeight) * fraction).toInt())
                if (view.isAttachedToWindow) windowManager.updateViewLayout(view, params)
            }
            start()
        }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (level < 0 || scale <= 0) return
            val percent = level * 100 / scale
            val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            handleBattery(percent, plugged)
        }
    }

    private fun registerBattery() {
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(batteryReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(batteryReceiver, filter)
        }
    }

    private fun handleBattery(percent: Int, plugged: Boolean) {
        val view = island ?: return
        val firstUpdate = !batterySeen
        batterySeen = true

        when {
            plugged && !charging -> {
                charging = true
                view.startCharging(percent, intro = !firstUpdate)
                if (mode != IslandMode.MEDIA) {
                    animateTo(IslandMode.CHARGE)
                    handler.postDelayed(collapseRunnable, peekDurationMs)
                }
            }
            plugged && charging -> view.updateLevel(percent)
            !plugged && charging -> {
                charging = false
                view.stopCharging()
                if (mode == IslandMode.CHARGE) animateTo(IslandMode.COLLAPSED)
            }
        }
    }

    private val controllerCallback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) = updateMedia()
        override fun onMetadataChanged(metadata: MediaMetadata?) = updateMedia()
    }

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { sessions -> pickController(sessions) }

    private fun hasNotificationAccess(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return enabled?.contains(packageName) == true
    }

    private fun setupMedia() {
        if (!hasNotificationAccess()) {
            clearMediaSession()
            showMediaAccessNeeded()
            return
        }
        try {
            val manager = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
            if (sessionManager == null) {
                manager.addOnActiveSessionsChangedListener(sessionsListener, listenerComponent)
                sessionManager = manager
            }
            pickController(manager.getActiveSessions(listenerComponent))
        } catch (_: SecurityException) {
            // Notification access may have been revoked while the overlay was running.
        }
    }

    private fun pickController(sessions: List<MediaController>?) {
        val best = sessions?.firstOrNull {
            it.playbackState?.state == PlaybackState.STATE_PLAYING
        } ?: sessions?.firstOrNull()

        if (best?.sessionToken != controller?.sessionToken) {
            controller?.unregisterCallback(controllerCallback)
            controller = best
            best?.registerCallback(controllerCallback)
        }
        updateMedia()
    }

    private fun updateMedia() {
        val view = island ?: return
        if (!hasNotificationAccess()) {
            clearMediaSession()
            showMediaAccessNeeded()
            return
        }
        val activeController = controller
        val metadata = activeController?.metadata

        view.titleText.text = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: if (hasNotificationAccess()) "Nothing playing" else "Media access needed"
        view.artistText.text = when {
            activeController == null && hasNotificationAccess() -> "Play something in a music app"
            activeController == null -> "Enable access in the app to see media"
            else -> metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST).orEmpty()
        }
        val playing = activeController?.playbackState?.state == PlaybackState.STATE_PLAYING
        view.playBtn.setImageResource(
            if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        )
        view.setPlaying(playing)
        loadArt(metadata)
    }

    private fun clearMediaSession() {
        controller?.unregisterCallback(controllerCallback)
        controller = null
        try {
            sessionManager?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (_: SecurityException) {
            // Notification access may already have been revoked.
        }
        sessionManager = null
        artKey = null
        island?.setAlbumArt(null)
        island?.setPlaying(false)
    }

    private fun showMediaAccessNeeded() {
        island?.apply {
            titleText.text = "Media access needed"
            artistText.text = "Enable access in the app to see media"
            setPlaying(false)
            setAlbumArt(null)
        }
    }

    private fun loadArt(metadata: MediaMetadata?) {
        val view = island ?: return
        if (metadata == null) {
            artKey = null
            view.setAlbumArt(null)
            return
        }

        val bitmap = metadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: metadata.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: metadata.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        if (bitmap != null) {
            artKey = null
            view.setAlbumArt(bitmap)
            return
        }

        val uri = listOf(
            MediaMetadata.METADATA_KEY_ALBUM_ART_URI,
            MediaMetadata.METADATA_KEY_ART_URI,
            MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI
        ).firstNotNullOfOrNull { key ->
            metadata.getString(key)?.takeIf { it.isNotBlank() }
        }
        if (uri == null) {
            artKey = null
            view.setAlbumArt(null)
            return
        }
        if (uri == artKey) return
        artKey = uri
        artExecutor.execute {
            val decoded = decodeArt(uri)
            handler.post {
                if (artKey == uri) island?.setAlbumArt(decoded)
            }
        }
    }

    private fun decodeArt(uriString: String): Bitmap? {
        return try {
            val uri = Uri.parse(uriString)
            val bytes = when (uri.scheme?.lowercase()) {
                "https" -> {
                    val connection = URL(uriString).openConnection() as? HttpsURLConnection
                        ?: return null
                    try {
                        connection.connectTimeout = 4000
                        connection.readTimeout = 4000
                        connection.instanceFollowRedirects = false
                        if (connection.responseCode !in 200..299) {
                            null
                        } else {
                            connection.inputStream.use(::readBounded)
                        }
                    } finally {
                        connection.disconnect()
                    }
                }
                "content" -> contentResolver.openInputStream(uri)?.use(::readBounded)
                else -> null
            } ?: return null

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sampleSize = 1
            while (max(bounds.outWidth, bounds.outHeight) / sampleSize > MAX_ART_DIMENSION) {
                sampleSize *= 2
            }
            BitmapFactory.decodeByteArray(
                bytes,
                0,
                bytes.size,
                BitmapFactory.Options().apply { inSampleSize = sampleSize }
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun readBounded(input: InputStream): ByteArray? {
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            if (total > MAX_ART_BYTES) return null
            output.write(buffer, 0, count)
        }
        return output.toByteArray()
    }

    private fun togglePlayPause() {
        if (!hasNotificationAccess()) {
            clearMediaSession()
            showMediaAccessNeeded()
            return
        }
        val activeController = controller
        if (activeController == null) {
            sendMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
        } else if (activeController.playbackState?.state == PlaybackState.STATE_PLAYING) {
            activeController.transportControls.pause()
        } else {
            activeController.transportControls.play()
        }
    }

    private fun skip(previous: Boolean) {
        if (!hasNotificationAccess()) {
            clearMediaSession()
            showMediaAccessNeeded()
            return
        }
        val activeController = controller
        if (activeController == null) {
            sendMediaKey(
                if (previous) KeyEvent.KEYCODE_MEDIA_PREVIOUS else KeyEvent.KEYCODE_MEDIA_NEXT
            )
        } else if (previous) {
            activeController.transportControls.skipToPrevious()
        } else {
            activeController.transportControls.skipToNext()
        }
    }

    private fun sendMediaKey(code: Int) {
        val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun startAsForeground() {
        val channelId = "dynamic_island_channel"
        val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.createNotificationChannel(
            NotificationChannel(
                channelId,
                "Dynamic Island",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows when the Dynamic Island overlay is active."
                setShowBadge(false)
            }
        )

        val openPendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopPendingIntent = PendingIntent.getBroadcast(
            this,
            1,
            Intent(this, StopOverlayReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("Dynamic Island is running")
            .setContentText("Tap the pill at the top of your screen")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentIntent(openPendingIntent)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setOngoing(true)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                getString(R.string.notification_stop),
                stopPendingIntent
            )
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        @Volatile
        var isActive: Boolean = false
            private set

        private const val NOTIFICATION_ID = 7412
        private const val MAX_ART_BYTES = 4 * 1024 * 1024
        private const val MAX_ART_DIMENSION = 512
    }
}
