# Dynamic Island for Android

A native Kotlin Android app with a user-started, Dynamic Island-style overlay. The pill animates battery charging and expands to show active media details and controls.

## Requirements

- Android Studio with Android SDK 35
- JDK 17 or newer
- Android 8.0 (API 26) or newer

## Open and run

1. Open this `android-dynamic-island` folder in Android Studio.
2. Let Gradle sync and install any requested Android SDK components.
3. Run the `app` configuration on an Android device or emulator.
4. In the app, grant **Display over other apps** access.
5. Optionally grant **Notification access** to show active song details and media controls.
6. Tap **Start overlay** and allow notifications so Android can show the ongoing service notification.

The overlay starts only after the user taps the in-app control. Android's Notification access is a broad permission; it is optional, and this app uses it only to read active media-session metadata and control playback. It does not inspect notification text. Album art loads from content URIs or HTTPS links supplied by the active media session. The app does not use an accessibility service, capture screen contents, or start automatically after reboot. Android may place system overlays differently depending on the device's camera cutout and status bar.

## Project

- `app/src/main/java/com/orbit/island/MainActivity.kt` — permission setup and app controls
- `app/src/main/java/com/orbit/island/OverlayService.kt` — `DynamicIslandService`, charging/media state, and foreground notification
- `app/src/main/java/com/orbit/island/IslandView.kt` — animated charging and media overlay UI
- `app/src/main/java/com/orbit/island/MediaListenerService.kt` — notification-listener component used for media-session access
- `app/src/main/java/com/orbit/island/StopOverlayReceiver.kt` — notification stop action
